package com.ch.ni.an.sharedpreferencesimplelesson

import android.support.v7.app.AppCompatActivity

open class BaseActivity: AppCompatActivity() {
}